@extends('layouts.frontend.main')

@section('content')
<h1 class="mt-4">Percontohan saja</h1>
<p>
    {{ $dt}}
    ini adalah isi dari percontohan. Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste saepe placeat ipsum nihil nam facere laboriosam earum consequatur? Deleniti nisi sequi soluta blanditiis aperiam commodi quisquam odit ipsum molestiae accusantium!
</p>



@endsection
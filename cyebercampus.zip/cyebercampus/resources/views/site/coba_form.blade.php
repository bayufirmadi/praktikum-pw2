@extebds('layout.frontend.main')

@selection('content')
<div class="mt-4">
    <form action="prosesform" method="POST">
        @csrf 
        <div class="form-group">
            <label for="nim">NIM</label>
            <input type="text" name="nim">
        </div>
        <div class="form-group">
            <label for="nama">NAMA</label><br>
            <input type="text" name="nama"><br>
        </div>

        <input type="submit" value="Kirim">
    </form>
</div>
@endsection
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hallo Semua</title>
</head>
<body>
    <h1>Apakabar</h1>
    <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tempora sapiente repudiandae minima! Corporis atque omnis eaque quaerat facilis quam, ipsum facere et. Deleniti aspernatur magni nulla eligendi id enim odit.</p>
</body>
</html>


<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Nama Ketua Jurusan <?=  $kajur ?></h1>
    
    <?php echo $nama_prodi ?>
    <p>Waktu Saat ini: <?php echo e(time()); ?></p>
    <?php if(5<10): ?> <h2> Kondisi Benar </h2>
        <?php endif; ?>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nulla sed deleniti sequi suscipit doloremque quae, dolorum, corporis obcaecati laborum ab necessitatibus in velit neque fuga inventore magni eum, facere reprehenderit?</p>
    <p>Nama Universitas : <?php echo e($universitas); ?></p>

   <h1>Program Studi Sistem Informasi</h1> 
   <p>Program Studi Sistem Informasi mulai beroperasi pada tahun 2014</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pbo\htdocs\pw 2\cyebercampus\resources\views/site/tentang.blade.php ENDPATH**/ ?>
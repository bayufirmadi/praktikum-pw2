
<?php $__env->startSection('content'); ?>
    <h1 class ="mt-4">Layanan</h1>
    <p>Layanan program studi sistem informasi meliputi:</p>
    <ol>
        <?php $__currentLoopData = $list_layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($ls); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pbo\htdocs\pw 2\cyebercampus\resources\views/site/layanan.blade.php ENDPATH**/ ?>
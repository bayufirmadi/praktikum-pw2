

<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Layanan kami (Eloquent)</h1>
<ul>
    <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lyn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li>  <?php echo e($lyn->nama_layanan); ?>  </li>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pbo\htdocs\pw 2\cyebercampus\resources\views/layanan/index.blade.php ENDPATH**/ ?>
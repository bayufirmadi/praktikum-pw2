

<?php $__env->startSection('content'); ?>
<h1 class="mt-4">Percontohan saja</h1>
<p>
    <?php echo e($dt); ?>

    ini adalah isi dari percontohan. Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste saepe placeat ipsum nihil nam facere laboriosam earum consequatur? Deleniti nisi sequi soluta blanditiis aperiam commodi quisquam odit ipsum molestiae accusantium!
</p>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pbo\htdocs\pw 2\cyebercampus\resources\views/site/percontohan.blade.php ENDPATH**/ ?>
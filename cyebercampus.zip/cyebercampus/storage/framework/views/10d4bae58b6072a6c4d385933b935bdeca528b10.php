@extebds('layout.frontend.main')

@selection('content')
    <form action="prosesform" method="POST">
        <?php echo csrf_field(); ?> 
        <label for="nim">NIM</label><br>
        <input type="text" name="nim"><br>
        <label for="nama">NAMA</label><br>
        <input type="text" name="nama"><br>
        <input type="submit" value="Kirim">
    </form>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\pbo\htdocs\pw 2\cyebercampus\resources\views/site/coba_form.blade.php ENDPATH**/ ?>
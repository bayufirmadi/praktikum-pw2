

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Detail Layanan</h1>
    Nama Layanan : <?php echo e($layanan->nama_layanan); ?> <br>
    Desktipsi layanan : <?php echo e($layanan->deskripsi_layanan); ?> <br>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\pbo\htdocs\pw 2\cyebercampus\resources\views/layanan/detail.blade.php ENDPATH**/ ?>